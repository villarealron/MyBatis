package co.vinod.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

import co.vinod.entity.Customer;

public interface CustomerDao {

	@Select("select * from customers")
	public List<Customer> getAllCustomers();
}
