package co.vinod.web;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.vinod.dao.CustomerDao;
import co.vinod.dao.DaoFactory;
import co.vinod.entity.Customer;

@WebServlet("/view-customers")
public class GetCustomersServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		CustomerDao dao = DaoFactory.getCustomerDao();
		List<Customer> list = dao.getAllCustomers();
		
		req.setAttribute("customers", list);
		
		req.getRequestDispatcher("/WEB-INF/views/show-customers.jsp").forward(req, resp);
		
	}

}
