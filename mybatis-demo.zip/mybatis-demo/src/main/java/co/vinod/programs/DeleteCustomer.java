package co.vinod.programs;

import java.io.IOException;

import co.vinod.dao.CustomerDao;
import co.vinod.dao.DaoFactory;
import co.vinod.entity.Customer;

public class DeleteCustomer {

	public static void main(String[] args) throws IOException {
		CustomerDao dao = DaoFactory.getCustomerDao();
		
		int id = 12;
		
		Customer c1 = dao.getCustomerById(id);
		
		if(c1==null) {
			System.out.println("No data found for id " + id);
		}
		else {
			dao.deleteCustomer(id);
			System.out.println("Customer with id "+id+" is deleted.");
		}
		
	}
}
