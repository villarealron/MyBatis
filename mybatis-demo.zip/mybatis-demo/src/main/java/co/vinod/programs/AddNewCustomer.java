package co.vinod.programs;

import java.io.IOException;

import co.vinod.dao.CustomerDao;
import co.vinod.dao.DaoFactory;
import co.vinod.entity.Customer;

public class AddNewCustomer {

	public static void main(String[] args) throws IOException {
		CustomerDao dao = DaoFactory.getCustomerDao();
		
		Customer c1 = new Customer();
		c1.setName("Satya");
		c1.setCity("Shimoga");
		c1.setEmail("satya123@example.com");
		c1.setPhone("9878767699");
		
		dao.addCustomer(c1);
		
		System.out.println(c1);
	}

}
